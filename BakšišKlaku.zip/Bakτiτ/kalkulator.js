function color(value){
    document.body.style.backgroundColor=value;
}
window.addEventListener("DOMContentLoaded", () => {
	document.getElementById("calculate").addEventListener("click", () => {
		const iznos = parseFloat(document.getElementById("iznos").value);
        
        if (isNaN(iznos)) return;

		const tipEl = document.getElementById("tip");
		const tip = Number.parseInt(tipEl.options[tipEl.selectedIndex].value).toFixed(
			2
		);
		const osobe = Number.parseInt(document.getElementById("osobe").value);

		const tipInDollars = iznos * (tip / 100);
		const subTotal = parseFloat(iznos + tipInDollars);
		const total = subTotal / osobe;

		document.querySelector(".info__tip").innerHTML = `⭐️Bakšiš: KM ${parseFloat(tipInDollars).toFixed(2)}`;
		document.querySelector(".info__total").innerHTML = `💰 Ukupno: KM ${total} ${osobe > 1 ? "svatko" : ""
		}`;
		document.querySelector(".info").style = "display: block";
	});
});